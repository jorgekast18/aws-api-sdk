This API contain the AWS-SDK for javascript and you can use the method Upload S3 and Compare Faces of rekognition tools.

---

## Documentation

You can enter to [Docu](https://bitbucket.org/reconoser/api-aws-sdk/wiki/Home) and see the url's, methods and parameter of each API.
